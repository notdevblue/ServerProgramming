class DataVO
{
   constructor(type, payload) {
      this.type = type;
      this.payload = payload;
   }
}

module.exports = DataVO;