const { WebSocketServer } = require("ws");
const path = require('path');
const fs = require("fs");
const DataVO = require("./VO/DataVO.js");
const topic = require("./Utils/Topic.js");

// 페킷들
/*
# 기타 
ok: {}            // 아무 문제 없이 잘 됬을 시 보냄 (서버)
err: paylaod      // 에러 발생 시 에러 내용을 보냄 (서버)
@init: { ind id } // 기본 데이터 전달 (서버)

# 로비
@createroom: payload (닉네임)                                         // 방 생성 (클라이언트)
@joinroom: { int id, string nickname }                                // 방 참가 위한 코드 입력 (클라이언트)
@joinroom: { List<userData> userData: { string nickname, int id } }   // 방 참가 시 알려주는 페킷 (서버)
@joined: { int id, string nickname }                                  // 추가로 방 참가한 유저 알려주는 페킷 (서버)

# 인게임
@chat: { int sender, string payload } // 체팅 (클라이언트, 서버)

@startgame: { string topic, string answer, bool isLiar } // 게임 시작했다고 알려주는 페킷 (서버)
@startgame: {}                                           // 게임 시작하라고 서버에게 요청 (클라이언트)

@voteTime: {}                    // 투표 시간이라고 알려주는 페킷 (서버)
@vote: { int id }                // 투표 (클라이언트)
@drop: { int id, bool isLiar }   // 투표 결과에 따른 플레이어 제외 (서버)

# 게임 종료 시
@answer: payload               // 라이어 답 입력 (클라이언트)
@liargameover: { bool result } // 라이어 입력한 답 정답 여부 (서버)
*/

const port = process.env.PORT || 38001;
const handlers = [];

const wss = new WebSocketServer({ port: port }, () => {
   console.log(`Server started on port ${port}.`);
});


// 동적 헨들러 임포트
fs.readdir(path.join(".", "Handlers"), (err, file) => {
   file.forEach(e => {
      console.log(`Found heandler ${e}`);
      const handler = require("./" + path.join("Handlers", e));
      handlers[handler.type] = handler.handle;
   });
});

let id = 0;

wss.on("connection", ws => {
   ws.clientId = ++id;
   ws.room = null;
   ws.voteCount = 0;
   ws.nickname = "";

   ws.send(JSON.stringify(new DataVO("init", JSON.stringify({ id: ws.clientId }))));

   console.log(`New user connected: ${ws.clientId}`);

   ws.on("message", packet => {
      let data = JSON.parse(packet);
      let handle = handlers[data.type];
      console.log(`client ${ws.clientId}: ${packet}`);

      if (handle == undefined) {
         console.log(`Cannot found handler for type ${data.type}`);
         return;
      }

      handle(data.payload, ws);
   });

   ws.on("close", (code, reason) => {
      console.log(`User ${ws.clientId} disconnected`);
      if (ws.room != undefined) {
         ws.room.removeUser(ws);
      }
   });
});