const RoomManager = require("../Utils/RoomManager");
const DataVO = require("../VO/DataVO");

module.exports = {
   type: "createroom",
   handle: (data, ws, params) => {
      if (ws.room == null) {
         ws.room = RoomManager.addRoom();
         console.log(ws.room.roomcode);
         ws.nickname = data;
         ws.room.addUser(ws);

         let userData = [];

         ws.room.users.forEach(e => {
            userData.push({
               nickname: e.nickname,
               id: e.clientId
            });
         });

         const payload = JSON.stringify({userData: userData});

         ws.send(JSON.stringify(new DataVO("joinroom", payload)));
      }
   }
}