module.exports = {
   type: "chat",
   handle: (data, ws, params) => {
      if (ws.room != null) {
         ws.room.chat(ws, JSON.parse(data).nickname);
      }
   }
}