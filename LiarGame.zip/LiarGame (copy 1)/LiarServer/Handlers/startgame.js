const RoomManager = require("../Utils/RoomManager");
const DataVO = require("../VO/DataVO");

module.exports = {
   type: "startgame",
   handle: (data, ws, params) => {
      if (ws.room != null) {
         ws.room.startGame();
      }
   }
}