module.exports = {
   type: "answer",
   handle: (data, ws, params) => {

      const payload = JSON.stringify({
         answer: ws.room.gameAnswer == data
      });

      ws.room.broadcast("liargameover", payload);
      ws.room.endGame();
   }
}