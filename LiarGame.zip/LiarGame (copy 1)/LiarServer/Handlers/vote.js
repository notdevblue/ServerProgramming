module.exports = {
   type: "vote",
   handle: (data, ws, params) => {
      if (ws.room != null) {
         console.log(data);
         
         data = JSON.parse(data);
         
         ws.room.vote(data.id);
      }
   }
}