const RoomManager = require("../Utils/RoomManager");
const DataVO = require("../VO/DataVO");

module.exports = {
   type: "joinroom",
   handle: (data, ws, params) => {
      data = JSON.parse(data);
      if (ws.room == null) {
         const room = RoomManager.joinRoom(data.id);
         ws.room = room;

         if (room == null) {
            ws.send(JSON.stringify(new DataVO("err", "cannot find room")));
         } else {
            ws.nickname = data.nickname;
            ws.room.addUser(ws); 
            
            let userData = [];

            ws.room.users.forEach(e => {
               userData.push({
                  nickname: e.nickname,
                  id: e.clientId
               });
            });

            const payload = JSON.stringify({userData: userData});

            ws.room = room;
            ws.send(JSON.stringify(new DataVO("joinroom", payload)));

            ws.room.broadcast("joined", JSON.stringify({
               id: ws.clientId,
               nickname: ws.nickname
            }));
         }
      }
   }
}