const Room = require("./Room");

class RoomManager
{
   constructor() {
      this.rooms = [];
      this.roomid = 0;
   }

   addRoom() {
      const room = new Room(++this.roomid);
      this.rooms[room.roomcode] = room;
      return room;
   }

   joinRoom(roomid) {
      return this.rooms[roomid];
   }

   deleteRoom(roomId) {
      const idx = this.rooms.indexOf(roomId);

      if (idx != -1)
         this.rooms.splice(idx, 1);
   }
}



module.exports = new RoomManager();