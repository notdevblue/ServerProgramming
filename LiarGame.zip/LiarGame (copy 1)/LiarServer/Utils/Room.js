const DataVO = require("../VO/DataVO.js");
const topic = require("./Topic.js");
const { exit } = require("process");

class Room
{
   constructor(roomcode) {
      this.roomcode = roomcode;
      this.users = [];
      this.isPlaying = false;

      this.gameTopic = "";
      this.gameAnswer = "";

      this.liarId = -1;

      this.voteUserLeft = -1;
      this.turn = 1;

      this.discussionTime = 1000 * 2;
      this.gameEnding = false;

      this.setTopic();
   }

   //#region 유틸
   broadcast(type, payload) {
      this.users.forEach(e => {
         e.send(JSON.stringify(new DataVO(type, payload)));
      });
   }

   chat(ws, msg) {
      if (ws.droped == undefined) {
         
         const payload = JSON.stringify({
            id: ws.clientId,
            nickname: msg
         });

         this.broadcast("chat", payload);
      }
   }

   addUser(ws) {
      if (!this.isPlaying)
         this.users[ws.clientId] = ws;
   }

   removeUser(ws) {
      let idx = this.users.indexOf(ws);

      // 예전에 유튜브에서 본 브렌치리스
      if (idx != -1)
         this.users.splice(idx, 1);
   }

   resetVoteCount() {
      this.users.forEach(e => {
         e.voteCount = 0;
      });
   }
   //#endregion

   //#region 게임 전 설정
   setTopic() {
      const topicIdx = (Math.random() * (topic.length - 1)) << 0;

      this.gameTopic = topic[topicIdx].type;
      this.gameAnswer = topic[topicIdx].payload;
   }

   setLiar() {
      let keys = Object.keys(this.users);
      const liarid = this.users[keys[keys.length * Math.random() << 0]];

      
      this.liarId = liarid.clientId;
   }
   //#endregion

   startGame() {
      this.isPlaying = true;
      
      this.resetVoteCount();
      this.setTopic();
      this.setLiar();

      this.users.forEach(e => {
         const payload = JSON.stringify({
            topic: this.gameTopic,
            answer: this.gameAnswer,
            isLiar: this.liarId == e.clientId
         });

         e.send(JSON.stringify(new DataVO("startgame", payload)));
      });

      this.voteUserLeft = this.users.length - 1;

      this.discuss();
   }


   //#region 게임 진행 중

   discuss() {
      setTimeout(() => {
         this.broadcast("votetime", "");
      }, this.discussionTime);
   }

   vote(targetId) {

      // 제외되지 않았고 id 가 존재하면
      if (this.users[targetId] != undefined) {
         ++this.users[targetId].voteCount;
         --this.voteUserLeft;

         // 투표 종료 시
         if (this.voteUserLeft <= 0) {
            this.voteUserLeft = this.users.length - this.turn++; // 플레이어 한명 드랍
            this.dropPlayerByVote();
         }
      }
   }

   dropPlayerByVote() {
      let maxVotedUser = null;
      let maxVoteCount = 0;

      this.users.forEach(e => {
         if (maxVoteCount < e.voteCount) {
            maxVoteCount = e.voteCount;
            maxVotedUser = e;
         }
      });

      let isLiar = this.liarId == maxVotedUser.clientId;
      this.gameEnding = isLiar;

      maxVotedUser.droped = true;

      this.broadcast("drop", JSON.stringify({ id: maxVotedUser.clientId, isLiar: isLiar }));

      if (!this.gameEnding) {
         this.resetVoteCount();
         this.discuss();
      } else {
         this.endGame();
      }
   }

   endGame() {
      this.users.forEach(e => {
         e.droped = undefined;
         e.room = undefined;
         e.voteCount = 0;
      });
   }

   //#endregion
}


const room = new Room();

module.exports = Room;