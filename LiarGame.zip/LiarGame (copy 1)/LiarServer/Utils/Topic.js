const fs = require("fs");
const DataVO = require("../VO/DataVO.js");

class Topic
{
   constructor() {
      this.csv = fs.readFileSync("datas.csv", () => {
   
      });
      
      this.arr = this.csv.toString().split('\r\n');
      this.result = [];
      
      this.arr.forEach(e => {
         let data = e.split(",");
         this.result.push(new DataVO(data[0], data[1]));
      });
      
      console.log("Topic loaded.");
   }
}

module.exports = new Topic().result;