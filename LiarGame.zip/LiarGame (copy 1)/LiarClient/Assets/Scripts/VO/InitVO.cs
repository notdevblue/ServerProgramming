using System;

[Serializable]
public class InitVO
{
   public int id;
}