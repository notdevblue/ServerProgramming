using System;


[Serializable]
public class StartGameVO
{
   public string topic;
   public string answer;
   public bool isLiar;
}