using System;

[Serializable]
public class VoteVO
{
   public int id;

   public VoteVO(int id)
   {
      this.id = id;
   }
}