using System;


[Serializable]
public class LiarGameOverVO
{
   public bool result = false;
}