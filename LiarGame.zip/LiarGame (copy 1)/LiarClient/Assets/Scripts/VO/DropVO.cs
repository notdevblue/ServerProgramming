using System;

[Serializable]
public class DropVO
{
   public int id;
   public bool isLiar;
}